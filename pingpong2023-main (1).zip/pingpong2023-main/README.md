# pingpong2023
Código de game pong para aula de Pensamento Computacional.
